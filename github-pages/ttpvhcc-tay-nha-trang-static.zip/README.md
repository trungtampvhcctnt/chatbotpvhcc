# TRUNG TÂM PHỤC VỤ HÀNH CHÍNH CÔNG PHƯỜNG TÂY NHA TRANG
## Gói triển khai Web tĩnh & GitHub Pages

### Cách 1: Chạy trực tiếp trên máy tính
- Mở file index.html bằng trình duyệt bất kỳ (Chrome, Edge, Cốc Cốc, Firefox).
- Có đầy đủ: Cổng DVC, Bảng niêm yết TTHC, Trợ lý ảo AI bồng bềnh nhấp nháy mắt, Kho E-Form 13 biểu mẫu, Đường dây nóng, Phiếu đánh giá.

### Cách 2: Triển khai lên GitHub Pages (Miễn phí 100%)
1. Tạo một repository mới trên GitHub (ví dụ: ttpvhcc-tay-nha-trang).
2. Tải toàn bộ các file trong thư mục này lên repository.
3. Vào Settings > Pages > Source: chọn 'Deploy from a branch' > branch 'main' / root.
4. Trang web sẽ hoạt động trực tiếp tại https://<username>.github.io/ttpvhcc-tay-nha-trang/

### Cách 3: Triển khai lên Netlify / Vercel
- Kéo thả toàn bộ thư mục này vào giao diện Drop của Netlify để có tên miền ngay trong 5 giây!
